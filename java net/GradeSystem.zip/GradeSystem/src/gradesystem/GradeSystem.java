
package gradesystem;


public class GradeSystem {


    public static void main(String[] args) {
        
    }
    
}
